from Int4_2_automaton import Automaton
import sys

# Allows creation of execution file
class Tee(object):
    def __init__(self, *files):
        self.files = files
    def write(self, obj):
        for f in self.files:
            f.write(obj)
            f.flush() # If you want the output to be visible immediately
    def flush(self) :
        for f in self.files:
            f.flush()


# Infinite loop to avoid relauching program to change automaton
run = True
while run:
    print("Welcome!\nEnter 0 to quit or select an automaton by number (1 to 30 or 36 to 44):")
    choice = int(input("\t==> "))
    while choice < 0 or (choice > 30 and choice < 36) or choice > 44:
        choice = int(input("Try again:\n\t==> "))
    if choice == 0:
        print("Goodbye!")
        run = False
    else:
        f = open('Int4-2-'+str(choice)+'-execution.txt','w')
        original = sys.stdout
        sys.stdout = Tee(sys.stdout, f)
        auto = Automaton(str(choice),f)
        run2 = True
        while run2:
            print("What would you like to do ?\n\t1.Standardization\n\t2.Determinization and completion\n\t"
              "3.Word recognition\n\t4.Complementary language\n\t\t0.Change automaton\n\t ==> ", end="")
            choice = input()
            while int(choice) < 0 or int(choice) > 4:
                choice = int(input("Enter a valid choice:\t==> "))
            auto.exc_file.write(str(choice) + "\n")
            if choice == '0':
                run2=False
            elif choice == '1':
                auto.menu_standardization()
            elif choice == '2':
                auto.menu_determinization()
            elif choice == '3':
                auto.menu_read_word()
            else:
                auto.complementary_language()

        sys.stdout = original
        f.close()
