from tabulate import tabulate

# A class to easily handle automata


class Automaton:
    # Initiates automaton by reading file and storing every information
    def __init__(self, name, ex_file):
        self.name = name
        self.exc_file = ex_file

        # Get the lines from the file
        fa_file = open(f"Int4-2-{name}.txt", 'r')

        self.symbols = (fa_file.readline()[:-1]).split(" ")
        self.n_states = (fa_file.readline()[:-1]).split(" ")
        self.i_states = (fa_file.readline()[:-1]).split(" ")
        self.f_states = (fa_file.readline()[:-1]).split(" ")
        self.n_transitions = (fa_file.readline()[:-1]).split(" ")
        self.transitions = []
        line = fa_file.readline()
        while line != "":
            self.transitions.append(line[:-1])
            line = fa_file.readline()
        fa_file.close()

        self.current_states = []
        for i in range(int(self.n_states[0])):
            self.current_states.append(str(i))
        #Specifications
        self.standard = None
        self.deterministic = None
        self.complete = None

        print("Automaton #" + self.name + ":")
        if self.name != 'comp':
            self.display()

    # Tests whether an automaton is standard
    def is_standard(self):
        if len(self.i_states)>1:
            self.standard = 0
        else:
            cp_transition = (self.transitions).copy()
            for transition in cp_transition:
                s_transition = transition.split(" ")
                if s_transition[-1] in self.i_states:
                    self.standard = -1
                    break
        if self.standard != 0 and self.standard != -1:
            self.standard = 1

    # Provides further explanation on standardness
    def std_explanation(self):
        if self.standard == 1:
            print("Automaton already standard.")
        else:
            print("Not standard: ", end="")
            if self.standard == 0:
                print("Multiple initial states.")
            elif self.standard == -1:
                print("Transition to initial state.")

    # Standardizes an automaton
    def standardization(self):
        cp_transition = (self.transitions).copy()
        for transition in cp_transition:
            s_transition = transition.split(" ")
            if s_transition[0] in self.i_states:
                self.transitions.append('I '+s_transition[1]+' '+s_transition[2])
        for state in self.i_states:
            if state in self.f_states:
                self.f_states.append('I')
                break
        self.n_states[0] = str(int(self.n_states[0])+1)
        self.i_states = ['I']
        self.n_transitions[0] = str(len(self.transitions))
        self.current_states.append('I')

    # Interface with user for standardization
    def menu_standardization(self):
        self.is_standard()
        self.std_explanation()
        if self.standard != 1:
            choice = int(input("Do you wish to standardize ?\n 1.Yes\n 0.No\n\t==> "))
            while choice !=0 and choice !=1:
                choice = int(input("Enter a valid choice:\t==> "))
            self.exc_file.write(str(choice)+"\n")
            if choice:
                self.standardization()
                print("Standardized:")
                self.display()

    # Tests whether an automaton is deterministic
    def is_deterministic(self):
        if self.deterministic != 1:
            if len(self.i_states)>1:
                self.deterministic = 0
            else:
                M = [ [0 for j in range(int(self.symbols[0])) ] for i in range(int(self.n_states[0])) ]
                for transition in self.transitions:
                    if transition[0] != 'I':
                        M[int(transition[0])][ord(transition[2])-97]+=1
                    else:
                        M[-1][ord(transition[2]) - 97] += 1
                for state in M:
                    if any(num >= 2 for num in state):
                        self.deterministic = -1
                        break
            if self.deterministic != 0 and self.deterministic != -1:
                self.deterministic = 1

    # Provides further explanation on deterministicness
    def det_explanation(self):
        if self.deterministic == 0:
            print("Not deterministic: Multiple initial states.")
        elif self.deterministic == -1:
            print("Not deterministic: Transition by a symbol has more than one outcome.")
        elif self.deterministic == 1:
            print("The automaton is deterministic")

    # Determinizes an automaton
    def determinization(self):
        current_state = []
        new_states =[]
        new_transition = []
        init_state = ''
        final_state = []
        for state in self.i_states:
            if init_state != '':
                init_state = init_state+'-'
            init_state = init_state+state
        new_states.append(init_state)
        current_state.append(init_state)
        while new_states:
            studied_state = new_states[0]
            for i in range(int(self.symbols[0])):
                symbol = chr(i+97)
                t_state = ''
                for j in range(0,len(studied_state),2):
                    cp_transition = (self.transitions).copy()
                    for transition in cp_transition:
                        s_transition = transition.split(" ")
                        if studied_state[j] == s_transition[0] and symbol == s_transition[1]:
                            if s_transition[2] not in t_state:
                                if t_state != '':
                                    t_state = t_state + '-'
                                t_state = t_state + s_transition[2]

                # Checks that the new state isn't already here or with switched numbers
                new = False
                if t_state != '' and t_state not in current_state:
                    new= True
                    for state in current_state:
                        new_states_test = []
                        for i in range(0,len(t_state),2):
                            new_states_test.append(t_state[i] in state)

                        if all(new_states_test):
                            new_state_confirm=[]
                            for j in range(0,len(state),2):
                                new_state_confirm.append(state[j] in t_state)
                            if all(new_state_confirm):
                                t_state = state
                                new = False
                                break

                if t_state != '':
                    if new:
                        new_states.append(t_state)
                        current_state.append(t_state)
                    new_transition.append(studied_state+' '+symbol+' '+t_state)
            del new_states[0]

        for state in current_state:
            for f_state in self.f_states:
                if f_state in state and state not in final_state:
                    final_state.append(state)

        self.n_states[0] = str(len(current_state))
        self.i_states = [init_state]
        self.f_states = final_state
        self.n_transitions[0] = str(len(new_transition))
        self.transitions = new_transition
        self.current_states = current_state
        self.deterministic = 1

    # Interface with user for determinization
    def menu_determinization(self):
        self.is_deterministic()
        self.det_explanation()
        if self.deterministic != 1:
            print("Determinization...")
            self.determinization()
        self.is_complete()
        self.comp_explanation()
        if self.complete != 1:
            print("Completion...")
            self.completion()
        self.display()

    # tests whether an automaton is complete
    def is_complete(self):
        if self.deterministic != 1:
            self.complete = 0
        else:
            M = [[0 for j in range(int(self.symbols[0]))] for i in range(int(self.n_states[0]))]
            cp_transition = (self.transitions).copy()
            for transition in cp_transition:
                s_transition = transition.split(" ")
                M[self.current_states.index(s_transition[0])][ord(s_transition[1]) - 97] += 1

            for state in M:
                if any(num < 1 for num in state):
                    self.complete = -1
                    break
        if self.complete != 0 and self.complete != -1:
            self.complete = 1

    # Completes an automaton
    def completion(self):
        if self.complete != 1:
            self.current_states.append('P')
            self.n_states[0] = str(int(self.n_states[0])+1)
            t_table = self.create_transition_table()
            for line in t_table:
                if '>' in line[0] and '<' in line[0]:
                    name_state = line[0][2:]
                elif '>' in line[0] or '<' in line[0]:
                    name_state = line[0][1:]
                else:
                    name_state = line[0]
                empty_transitions = [i for i, x in enumerate(line) if x == "_"]
                if empty_transitions:
                    for index in empty_transitions:
                        self.transitions.append(name_state+' '+chr(index+96)+' '+'P')
                        self.n_transitions[0] = str(int(self.n_transitions[0])+1)
            self.complete = 1

    # Provides further explanation on completeness
    def comp_explanation(self):
        if self.complete == 0:
            print("Not complete: The automaton is not deterministic.")
        elif self.complete == -1:
            print("Not complete: Not all states have a transition per symbol of the alphabet.")
        elif self.complete == 1:
            print("The automaton is complete.")

    # Tests whether a word is recognized by an automaton
    def read_word(self,word):
        self.is_deterministic()
        if self.deterministic != 1:
            self.determinization()
        self.is_complete()
        if self.complete != 1:
            self.completion()
        recognized = True
        advance = False
        next_state = self.i_states[0]
        c_state = self.i_states[0]
        for letter in word:
            cp_transition = (self.transitions).copy()
            for transition in cp_transition:
                s_transition = transition.split(" ")
                if c_state == s_transition[0] and letter == s_transition[1]:
                    advance = True
                    next_state = s_transition[2]
                    break
            if advance:
                c_state = next_state
                advance = False
            else:
                recognized = False
                break
        if recognized:
            if c_state not in self.f_states:
                recognized = False
        return recognized

    # Interface with user for word recognition
    def menu_read_word(self):
        print("Recognition from complete deterministic finite automaton:")
        self.is_deterministic()
        if self.deterministic != 1:
            self.determinization()
        self.is_complete()
        if self.complete != 1:
            self.completion()
        self.display()
        print("Enter a word or 'quit' to stop recognition:\n\t==> ",end="")
        word = input()
        self.exc_file.write(word + "\n")
        while word != 'quit':
            read = self.read_word(word)
            if read:
                print("Word recognized!")
            else:
                print("Word not recognized.")
            print("Enter a word or 'quit' to stop recognition:\n\t==> ",end="")
            word = input()
            self.exc_file.write(word + "\n")

    # Creates complement and allows to test words
    def complementary_language(self):
        print("Complementary obtained from complete deterministic finite automaton:")
        self.is_deterministic()
        if self.deterministic != 1:
            self.determinization()
        self.is_complete()
        if self.complete != 1:
            self.completion()
        self.display()
        f = self.exc_file
        complement = Automaton('comp',f)
        complement.symbols = self.symbols
        complement.n_states = self.n_states
        complement.i_states = self.i_states
        complement.n_transitions = self.n_transitions
        complement.transitions = self.transitions
        complement.current_states = self.current_states
        complement.standard = self.standard
        complement.deterministic = self.deterministic
        complement.complete = self.complete
        new_final_states = []
        for state in self.current_states:
            if state not in self.f_states:
                new_final_states.append(state)
        complement.f_states = new_final_states
        complement.display()
        complement.menu_read_word()

    # Creates the transition table of an automaton
    def create_transition_table(self):
        t_table = []
        for i in range(int(self.n_states[0])):
            name_state = self.current_states[i]
            t_line =[]
            c_state = ''
            if name_state in self.f_states:
                c_state = c_state+'<'
            if name_state in self.i_states:
                c_state = c_state+'>'
            c_state = c_state+name_state
            t_line.append(c_state)
            for j in range(int(self.symbols[0])):
                t_state = ''
                cp_transition = (self.transitions).copy()
                for transition in cp_transition:
                    s_transition = transition.split(" ")
                    if name_state == s_transition[0] and chr(j+97)== s_transition[1]:
                        if t_state != '':
                            t_state = t_state+'-'
                        t_state = t_state+s_transition[2]
                if t_state != '':
                    t_line.append(t_state)
                else:
                    t_line.append('_')
            t_table.append(t_line)
        return t_table

    # Prepares table for proper display
    def create_table(self):
        headers = ['']
        for i in range(int(self.symbols[0])):
            headers.append(chr(ord('a')+i))
        table = []
        table.append(headers)
        t_table = self.create_transition_table()
        for line in t_table:
            table.append(line)
        return table

    # Displays automaton
    def display(self):
        table = self.create_table()
        print(tabulate(table, headers='firstrow', tablefmt='grid'))
